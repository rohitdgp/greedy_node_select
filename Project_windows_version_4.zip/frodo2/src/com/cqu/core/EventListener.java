package com.cqu.core;

public interface EventListener {
	void onStarted();
	void onFinished(Object result);
}
